<?
/**
 * Include-file with configuration parameters
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: config.inc.php.dist,v 1.3 2005/09/19 11:22:13 brischniz Exp $
 **/
 
// copy this file to config.inc.php and adjust the parameters to your needs

/////////////////////////////////////////////////////////////////////////////
// PHP related parameters
/////////////////////////////////////////////////////////////////////////////

if(!isset($_REQUEST['debug'])) {
  ini_set('display_errors', 0);
  error_reporting(E_ALL ^ E_WARNING);
}
else {
  if($_REQUEST['debug'] == '1') {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
  }
}

set_time_limit(3600);

/////////////////////////////////////////////////////////////////////////////
// XML2OWL related parameters
/////////////////////////////////////////////////////////////////////////////


// Change the value to 'yes', if you want to use xml2owl in conjunction with pOWL
$_XML2OWL['standalone'] = 'no';

// The pOWL path on your webserver
$_XML2OWL['powlURI'] = 'http://localhost/powl';

// Language (not supported yet)
$_XML2OWL['language'] = "en";  // en, de

// This is the path for temporary files. It has to be a path with write permission
// for the webserver. Uncomment and adjust one line for your needs.
$_XML2OWL['tempPath'] = getcwd();                      // normal installation
//$_XML2OWL['tempPath'] = "/tmp/persistent/xml2owl";   // extra solution for sourceforge.net
//$_XML2OWL['tempPath'] = "";                          // any other path

$_XML2OWL['uploadPath'] = $_XML2OWL['tempPath'] . "/upload";
$_XML2OWL['targetPath'] = $_XML2OWL['tempPath'] . "/tmp";


$cmd_ret = `whereis xsltproc`;
$pathToXsltproc = explode(" ", substr($cmd_ret, 10, strlen($cmd_ret)));
$_XML2OWL['pathToXsltproc'] = $pathToXsltproc[0];

$servername = isset($HTTP_SERVER_VARS['SERVER_NAME'])?$HTTP_SERVER_VARS['SERVER_NAME']:$_SERVER['SERVER_NAME'];
$req_uri = isset($HTTP_SERVER_VARS['REQUEST_URI'])?$HTTP_SERVER_VARS['REQUEST_URI']:$_SERVER['REQUEST_URI'];

$_XML2OWL['localURI'] = "http://" . $servername . substr($req_uri, 0, strrpos($req_uri, '/'));

// Path to the main stylesheet
$_XML2OWL['pathToMainStylesheet'] = realpath("xsl/xsd2owl.xsl");

// Path to external XSLT library 'xsltsl' - if not available, XML2OWL will not work
$_XML2OWL['pathToXSLTSLlib'] = getcwd() . "/libs/xsltsl-1.2.1/stdlib.xsl";

// Debug Level
$_XML2OWL['debug'] = isset($_REQUEST['debug'])?$_REQUEST['debug']:0;

// predefined Use Cases
$xmlOnServer = array(0=>"examples/oai_citeseer1",
                    1=>"examples/example1.xml",
                    2=>"examples/exceltest.xml",
                    3=>"examples/firebird_job.xml");

$_XML2OWL['title'] = $_XML2OWL['standalone']=='no'?'XML2OWL mapping wizard':'XML2OWL demonstration platform';

$_XML2OWL['errors'] = array();

/////////////////////////////////////////////////////////////
// no further parameters below this line

if(!file_exists($_XML2OWL['tempPath'])) {
  mkdir($_XML2OWL['tempPath']);
}
if(!file_exists($_XML2OWL['uploadPath'])) {
  mkdir($_XML2OWL['uploadPath']);
}
if(!file_exists($_XML2OWL['targetPath'])) {
  mkdir($_XML2OWL['targetPath']);
}

// loads pOWL-API, if XML2OWL is installed in conjunction with pOWL
if($_XML2OWL['standalone'] == 'no') {
  if(is_file('../../include.php')) {
   include('../../include.php');
  }
  else {
    array_push($_XML2OWL['errors'], "If you do not have a local pOWL installation, please turn the 'standalone' switch. to 'yes' ");
  } 
}

// Detection, which XSLT processor to use
$builtin_libxslt = detectXSLTProcessor();
if(!$builtin_libxslt && $_XML2OWL['pathToXsltproc'] == '') {
  array_push($_XML2OWL['errors'], "You do not have any XSLT processor available. To use xml2owl you have to install one.");
}

if(!is_file($_XML2OWL['pathToXSLTSLlib'])) {
  array_push($_XML2OWL['errors'], "XSLTSL library is not available, please install it.");
}

// Errors occured? ////////////////////////////////////////////////////////////////////////////////
if(count($_XML2OWL['errors']) > 0) {
  echo '<html><head><link rel="stylesheet" type="text/css" href="css/main.css"/></head><body>';
  while(list($key, $wert) = each($_XML2OWL['errors'])) {
    echo '<div id="errors">' . $key . ': ' . $wert . '</div>';
  }
  echo '</body></html>';
  
  die("Please correct the errors first.");
}

?>