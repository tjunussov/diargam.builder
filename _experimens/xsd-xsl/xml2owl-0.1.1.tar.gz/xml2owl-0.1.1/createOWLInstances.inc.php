<?
/**
 * Include-file, which maps the XML instance data into OWL instances, with the help
 * of the generated stylesheet from the last step.
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: createOWLInstances.inc.php,v 1.8 2005/09/21 07:55:53 brischniz Exp $
 **/
 
	// debug section
	echo "<!-- XML File: " . $chosenXMLFile . "-->\n";
	echo "<!-- Import Model: " . $powlModel . "-->\n";

  $modelToImport = $powlModel==''?$_XML2OWL['localURI'] . "/model.owl":$powlModel;
  
  if($builtin_libxslt) {
  	$xsl = new XSLTProcessor();
    $xsl->importStylesheet(DOMDocument::load($createdStylesheet));
    
    $xsl->setParameter('', 'modelPrefix', $modelPrefix);
    $xsl->setParameter('', 'importURIsForInstances', $modelToImport);
  
    $timestart = microtime(true);  
    $xsl->transformToXML(DOMDocument::load($chosenXMLFile));
    $timeend = microtime(true); 
  }
  else {
    $param_string = "--stringparam importURIsForInstances '" . $modelToImport . "'";
    $param_string .= " --stringparam modelPrefix '" . $modelPrefix . "'";
    $exec_string = $_XML2OWL['pathToXsltproc'] . " " . $param_string . " " . $createdStylesheet . " " . $chosenXMLFile;
    
    $timestart = microtime_float();
    echo "<!-- exec string: " . $exec_string . "-->";
    shell_exec($exec_string);
    //chmod('tmp/' . $tmpID . '/instances.owl', 0666);
    $timeend = microtime_float();
  }
  
?>
<div id="instancesCreated">
	<h4>OWL instances created in <? echo round($timeend - $timestart, 2);?> seconds</h4>
	<ul>
		<li><a href="filedownload.php?file=<?=$_XML2OWL['targetPath']?>/model.owl">model.owl <img src="img/d1.ico" width="13"/></a> <a href="#" onclick="xml2owl.showCode('<?=$_XML2OWL['targetPath']?>/model.owl');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a></li>
		<li><a href="filedownload.php?file=<?=$_XML2OWL['targetPath']?>/instances.owl">instances.owl <img src="img/d1.ico" width="13"/></a> <a href="#" onclick="xml2owl.showCode('<?=$_XML2OWL['targetPath']?>/instances.owl');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a></li>
	</ul>
</div>

<div id="instancesCreatedRightSide" class="options">
	<?if($_XML2OWL['standalone'] == 'no') {?>
	<h3>Load this ontology into pOWL</h3>
	<input id="delFiles" type="checkbox" name="delFiles" value="true" style="margin-left:25px;"/> Delete temporary files after import<br/><br/>
	<a href="#" onclick="xml2owl.forwardToPowlLoad('<?=$tmpID?>', 'instances.owl');" style="margin-left:25px;"><img id="btn_loadintopowl" src="img/btn_loadintopowl.png" onmouseover="document.getElementById('btn_loadintopowl').src='img/btn_loadintopowl_mover.png'" onmouseout="document.getElementById('btn_loadintopowl').src='img/btn_loadintopowl.png'"/></a>
	<?}
	else {?>
	<a href="index.php?input=del&amp;delID=<?=$tmpID?>">Delete temporary files and return to Startpage <img src="img/delete.gif"/></a>
	<?}?>
</div>