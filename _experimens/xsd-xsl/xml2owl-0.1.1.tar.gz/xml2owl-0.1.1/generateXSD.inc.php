<?
/**
 * Include-file which provides the XML Schema extraction out of an Xml instance file.
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: generateXSD.inc.php,v 1.6 2005/09/21 06:35:30 brischniz Exp $
 **/	
	
	$guessCardinality = isset($_REQUEST['guessCard'])?'true':'false';
	
  if($builtin_libxslt) {
  	$xsl = new XSLTProcessor();
  	$xsl->importStylesheet(DOMDocument::load($_XML2OWL['pathToMainStylesheet']));
    
    $xsl->setParameter('', 'input', 'xml');	
    $xsl->setParameter('', 'guessCardinality', $guessCardinality);
    $xsl->setParameter('', 'targetPath', $_XML2OWL['targetPath']);
    
    // creates an XML Schema file 'schema.xsd'
    $xsl->transformToXML(DOMDocument::load($chosenXMLFile));
  }
  else {
    $param_string = "--stringparam input 'xml' --stringparam guessCardinality '" . $guessCardinality . "'";
    $param_string .= " --stringparam targetPath '" . $_XML2OWL['targetPath'] . "'";
    $exec_string = $_XML2OWL['pathToXsltproc'] . " " . $param_string . " " . $_XML2OWL['pathToMainStylesheet'] . " " . $chosenXMLFile;
    
    echo "<!-- exec_string: " . $exec_string . "-->\n";
    shell_exec($exec_string);
  }
	
?>
<div id="xsdGenerated">
	<h4>Here is the extracted XML Schema</h4>
	<ul>
		<li><a href="filedownload.php?file=<?=$_XML2OWL['targetPath']?>/schema.xsd">schema.xsd <img src="img/d1.ico" width="13"/></a> <a href="#" onclick="xml2owl.showCode('<?=$_XML2OWL['targetPath']?>/schema.xsd');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a></li>
	</ul>
</div>

<div id="modelOptions" class="options">

	<div id="optModelExt">
		<h3>Options for the OWL model extraction</h3>
		<input type="checkbox" name="camelCase" value="true"/>
		Check, if you want CamelCase for classes and properties <a onMouseOver="return overlib('This option formats the OWL output with CamelCase. ', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a><br/>
		<input type="checkbox" name="funcPropSupp" value="true"/>
		Detect functional properties <a onMouseOver="return overlib('Stylesheet tries to detect functional properties. Every xsd:attribute and every xsd:element with minOccurs={0|1} and maxOccurs=1 will become a functional property.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a><br/>
		<input type="text" name="opPrefix" value="has"/> Prefix for ObjectProperties<a onMouseOver="return overlib('This sets the prefix for the owl:ObjectProperties. The default value is has.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a><br/>
		<input type="text" name="dtpPrefix" value="dtp"/> Prefix for DatatypeProperties<a onMouseOver="return overlib('This sets the prefix for the owl:DatatypeProperties. The default value is dtp.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a>
		<br/>

	</div>
	<script language="javascript">
		document.getElementById('optModelExt').style.display='block';
	</script>
</div>


