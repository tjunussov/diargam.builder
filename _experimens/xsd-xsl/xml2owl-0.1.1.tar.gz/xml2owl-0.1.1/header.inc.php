<?
/**
 * Header file
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: header.inc.php,v 1.8 2005/10/23 13:31:51 brischniz Exp $
 **/
?>

<html>
<head>
  <title><?=$_XML2OWL['title']?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/xmlverbatim.css"/>
  <link rel="stylesheet" type="text/css" href="css/main.css"/>
  <link rel="stylesheet" type="text/css" href="css/buttons.css"/>
  <script language="javascript" src="libs/tooltip.js"></script>
  <script language="javascript" src="functions.js"></script>
</head>
<body>
<DIV ID="overDiv" STYLE="position:absolute; visibility:hidden; z-index:1000;"></DIV>
<form name="mainForm" action="index.php" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="input" value="<?=$nextStep?>"/>
  <input type="hidden" name="docType" value="<?=$docType?>"/>
  <input type="hidden" name="tmpID" value="<?=$tmpID?>"/>
  <input type="hidden" name="debug" value="<?=$_XML2OWL['debug']?>"/>
  <input type="hidden" name="chosenXMLFile" value="<?=$chosenXMLFile?>"/>

<h2><?=$_XML2OWL['title']?></h2>

<div id="btn_home" class="figure">
  <a href="index.php">
    <img class="btn_home" src="img/btn_about.gif"/>
  </a>
  <a id="btn_text_home" href="index.php">Home</a>
</div>
<?if($_XML2OWL['standalone']=='no') {?>
<div id="btn_powl" class="figure">
  <a href="<?=$_XML2OWL['powlURI']?>">
    <img class="btn_about" src="img/btn_about.gif"/>
  </a>
  <a id="btn_text_about" href="<?=$_XML2OWL['powlURI']?>">pOWL</a>
</div>
<?}?>
<div id="btn_help" class="figure">
  <a href="index.php?input=help">
    <img class="btn_help" src="img/btn_about.gif"/>
  </a>
  <?if($input == 'help') {?>
    <a id="btn_text_help" href="#" onclick="history.back();">Back</a>
  <?}else {?>
    <a id="btn_text_help" href="index.php?input=help">Help</a>
  <?}?>
</div>
<div id="btn_about" class="figure">
  <a href="index.php?input=about">
    <img class="btn_about" src="img/btn_about.gif"/>
  </a>
  <?if($input == 'about') {?>
    <a id="btn_text_about" href="#" onclick="history.back();">Back</a>
  <?}else {?>
     <a id="btn_text_about" href="index.php?input=about">About</a>
  <?}?>
</div>

<?if($input != 'help' && $input != 'about') {?>

  <div id="stepImage">
    <map name="processImg">
      <?=$mapAreas?>
    </map>
    <img id="mainImg" src="<?=$actualPicturePath?>" usemap="#processImg"/><br/>
    Picture shows next step.
  </div>

  <div id="statposDiv">
	<?if($input != 'chooseXML') {
		  if($docType == 'xml') {?>
    <div><a href="index.php" style="text-decoration:underline;">1. Choose an input document</a></div>
    <div class="<?=$input=='generateXSD'?'statpos':''?>">2. XML Schema extracted</div>
    <div class="<?=$input=='createOWLModel'?'statpos':''?>">3. OWL model and configured stylesheet generated</div>
    <div class="<?=$input=='createInstances'?'statpos':''?>">4. OWL instances created</div>
			<?}
			else if($docType == 'xsd') {?>
    <div><a href="index.php">1. Choose an input document</a></div>
    <div class="<?=$input=='createOWLModel'?'statpos':''?>">2. OWL model and configured stylesheet generated</div>
			<?}?>
		<?}
		else {?>
    <div class="statpos">1. Choose an input document</a></div>
    <div>2. XML Schema extracted</div>
    <div>3. OWL model and configured stylesheet generated</div>
    <div>4. OWL instances created</div>
		<?}?>
  </div>
<?}?>


