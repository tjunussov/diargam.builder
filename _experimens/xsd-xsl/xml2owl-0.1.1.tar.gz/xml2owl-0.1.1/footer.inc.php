<?
/**
 * footer.inc.php
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: footer.inc.php,v 1.5 2005/10/23 13:31:51 brischniz Exp $
 **/
?>
	
	<?if($input != 'help' && $input != 'about') {?>
	<div id="footer">
		<p>
			<b>Hint:</b> <?=$actualHint?>
		</p>
		<input id="prevstep" type="image" src="img/btn_prevstep.gif" name="backButton" onmouseover="document.getElementById('prevstep').src='img/btn_prevstep_mover.gif'" onmouseout="document.getElementById('prevstep').src='img/btn_prevstep.gif'" onclick="window.history.back();return false;"/>
		<?if(!$last) {?>
			<input id="nextstep" type="image" src="img/btn_nextstep.gif" onmouseover="document.getElementById('nextstep').src='img/btn_nextstep_mover.gif'" onmouseout="document.getElementById('nextstep').src='img/btn_nextstep.gif'"/>
		<?}?>
	</div>
	<?}?>
</form>
</body>

</html>