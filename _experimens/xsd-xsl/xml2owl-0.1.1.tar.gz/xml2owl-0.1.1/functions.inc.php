<?
/**
 * Useful functions
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: functions.inc.php,v 1.7 2005/09/21 06:35:30 brischniz Exp $
 **/


function detectXSLTProcessor() {
  global $_XML2OWL;
  
	if(class_exists('XSLTProcessor')) {
		$xsl = new XSLTProcessor();
		if($xsl->hasExsltSupport()) {
			//echo "exslt vorhanden...<br/>";
			return true;
		}
		else {
			if($_XML2OWL['pathToXsltproc'] == "") {
				echo "You do not have an XSLT processor available with libxslt support. Please specify one in the config.inc.php file.";
				exit;
			}
			return false;
		}
	}
	else {
		if($_XML2OWL['pathToXsltproc'] == "") {
			echo "You do not have an XSLT processor available with libxslt support. Please specify one in the config.inc.php file.";
			exit;
		}
		return false;
	}
}

function provideDebugInformations() {
  global $_XML2OWL;
  
	if($_XML2OWL['debug'] == 1) {
		echo '<div style="background-color:#CC9090;margin:2px;width:300px;border:1px solid black;"><table style="font-size:12px;">';
		while(list($key, $wert) = each($_REQUEST)) {
			echo "<tr><td><b>" . $key . ":</b></td><td>" . $wert . "</td></tr>";
		}
		echo '</table></div>';
	}
	
	if($_XML2OWL['debug'] == 2) {
		echo '<div style="background-color:#CC9090;margin:2px;width:700px;border:1px solid black;">
		<table style="font-size:12px;">';
		while(list($key, $wert) = each($_SERVER)) {
			echo "<tr><td><b>" . $key . ":</b></td><td>" . $wert . "</td></tr>";
		}
		echo '</table></div>';
	}
	
	if($_XML2OWL['debug'] == 1) {
		echo '<div style="background-color:#CC9090;margin:2px;width:300px;border:1px solid black;"><table style="font-size:12px;">';
			echo "<tr><td><b>localURI:</b></td><td>" . $_XML2OWL['localURI'] . "</td></tr>";
		echo '</table></div>';
	}
}

/**
* returns the absolute path of the input file
*/
function getFilePath($input, $tmpID, $uploadPath) {
	switch ($input) {
		case 'chooseXML':
			return realpath($_REQUEST['chosenXMLFile']);
			break;
		case 'upload':
			$uploadFileEndSavePath = $uploadPath . "/" . $_FILES['file']['name'] . '_' . $tmpID;
			if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFileEndSavePath)) {
				//chgrp($uploadFileEndSavePath, "users");
				chmod($uploadFileEndSavePath, 0666);
			}
			return $uploadFileEndSavePath;
			break;
		case 'enterCode':
			if(isset($_REQUEST['userXML'])) {
				$uploadFileType = $_REQUEST['filetype'];
				$uploadFileEndSavePath = $uploadPath . "/custom_" . $tmpID . "." . $uploadFileType;
				$handle = fopen($uploadFileEndSavePath, "w");
				fputs($handle, str_replace("\\", "", $_REQUEST['userXML']));
				fclose($handle);
				chmod($uploadFileEndSavePath, 0666);
				return $uploadFileEndSavePath;
			}
			break;
		default:
			return realpath($_REQUEST['chosenXMLFile']);
			break;
	}
}

/**
* Deletes a directory recursively, even if it is not empty 
*/
function rmdirr($dir) {
   if($objs = glob($dir."/*")){
       foreach($objs as $obj) {
           is_dir($obj)? rmdirr($obj) : unlink($obj);
       }
   }
   rmdir($dir);
}

/**
* Simple function to replicate PHP5 behaviour
*/
function microtime_float() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}

/**
* Detect whether a file is an XML document or an XML Schema
*/
function detectFileType($uri, $builtin_libxslt) {
	if($builtin_libxslt) {
		if (!$dom = DOMDocument::load($uri)) {
			echo "Error while parsing the document\n";
		}
		
		$root = $dom->documentElement->tagName;
		return strpos($root, 'schema')===false?'xml':'xsd';
	}
	else {
		include('xmlparser.inc.php');
		$xml = new xml_doc($uri);
		$xml->parse();

		$root_tag =& $xml->xml_index[0];
		echo $root_tag;exit;
	}
}

/**
* for loading an ontology into a remote pOWL
*/
function http_post($server, $port, $url, $vars) {

	// example:
	//  http_post("www.fat.com",80,"/weightloss.pl",array("name" => "obese bob", "age" => "20"));
	
	$user_agent = "Mozilla/4.0 (compatible; MSIE 5.5; Windows 98)";
	
	
	$urlencoded = "";
	while (list($key,$value) = each($vars))
		$urlencoded.= urlencode($key) . "=" . urlencode($value) . "&";
	$urlencoded = substr($urlencoded,0,-1);
	
	$content_length = strlen($urlencoded);
	
	$headers = "POST $url HTTP/1.1
	Accept: */*
	Accept-Language: en-au
	Content-Type: application/x-www-form-urlencoded
	User-Agent: $user_agent
	Host: $server
	Connection: Keep-Alive
	Cache-Control: no-cache
	Content-Length: $content_length
	
	";
	
	$fp = fsockopen($server, $port, $errno, $errstr);
	if (!$fp) {
		return false;
	}
	
	fputs($fp, $headers);
	fputs($fp, $urlencoded);


	$ret = "";
	while (!feof($fp))
		$ret.= fgets($fp, 1024);
					
	fclose($fp);
	
	return $ret;

}


?>