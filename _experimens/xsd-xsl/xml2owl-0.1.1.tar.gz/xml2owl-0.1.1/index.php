<?
/**
 * Main file of xml2owl
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: index.php,v 1.10 2005/09/21 07:55:53 brischniz Exp $
 **/

 
include('functions.inc.php');
include('config.inc.php');

if($_XML2OWL['debug'] >= 1) {
	provideDebugInformations();
}

if(!isset($_REQUEST['tmpID'])) {
	$tmpID = uniqID("");
	$_XML2OWL['targetPath'] .= "/" . $tmpID;
	$_XML2OWL['localURI'] .= "/tmp/" . $tmpID;
	mkdir($_XML2OWL['targetPath']);
	//chmod($_XML2OWL['targetPath'], 0777);
}
else {
	$tmpID = $_REQUEST['tmpID'];
	$_XML2OWL['targetPath'] .= "/" . $tmpID;
	$_XML2OWL['localURI'] .= "/tmp/" . $tmpID;
}

$area_schema ='<area shape="rect" coords="59,20,115,85" href="filedownload.php?file='.$_XML2OWL['targetPath'].'/schema.xsd" title="The XML Schema"/>';
$area_xml = '<area shape="rect" coords="59,172,115,238" href="#" title="The XML instance document"/>';
$area_model = '<area shape="rect" coords="300,33,357,103" href="filedownload.php?file='.$_XML2OWL['targetPath'].'/model.owl" title="The OWL model"/>';
$area_instances = '<area shape="rect" coords="300,151,357,226" href="filedownload.php?file='.$_XML2OWL['targetPath'].'/instances.owl" title="The OWL instances"/>';
$area_stylesheet = '<area shape="rect" coords="160,87,290,145" href="filedownload.php?file='.$_XML2OWL['targetPath'].'/createInstances.xsl" title="The generated stylesheet"/>';

// Flag for last page
$last = false;

if(!isset($_REQUEST['input'])) {
  $actualHint = 'You can choose between an example XML file, uploading an XML or XSD document or pasting own code.';
	$input = 'chooseXML';
  $actualPicturePath = 'img/0.png'; 
}
else if($_REQUEST['input'] == 'del') {
  if(isset($_REQUEST['delID']) && $_REQUEST['delID'] != '') {
    rmdirr($_XML2OWL['targetPath'] . '/../' . $_REQUEST['delID']);
    $input = 'chooseXML';
    $actualHint = 'Your temporary files were deleted.';
    $actualPicturePath = 'img/0.png'; 
  }
}
else if($_REQUEST['input'] != 'help' && $_REQUEST['input'] != 'about'){
	$input = $_REQUEST['input'];
	$chosenXMLFile = getFilePath($input, $tmpID, $_XML2OWL['uploadPath']);

	if($chosenXMLFile != '') {
		$docType = !isset($_REQUEST['filetype'])?"xml":$_REQUEST['filetype'];
		
		if($docType == 'xml') {
			if($input == 'chooseXML' || $input == 'upload' || $input == 'enterCode') {
				$input = 'generateXSD';
				$nextStep = 'createOWLModel';
				$actualPicturePath = 'img/2.png';
				$actualHint = 'The XML Schema has been extracted. It will be used for creating the OWL model.';
				$mapAreas = $area_xml . $area_schema;
			}
			if($input == 'createOWLModel') {
				$nextStep = 'createInstances';
				$opPrefix = isset($_REQUEST['opPrefix'])?$_REQUEST['opPrefix']:'has';
				$dtpPrefix = isset($_REQUEST['dtpPrefix'])?$_REQUEST['dtpPrefix']:'dtp';
				$camelCase = isset($_REQUEST['camelCase'])?'true':'false';
				$funcPropSupp = isset($_REQUEST['funcPropSupp'])?'true':'false';
				$actualPicturePath = 'img/3.png';
				$actualHint = 'The OWL model is ready. Furthermore, the stylesheet for your XML instance file has been created.';
				$mapAreas = $area_xml . $area_schema . $area_model . $area_stylesheet;
			}
			if($input == 'createInstances') {
				$createdStylesheet = $_XML2OWL['targetPath']."/createInstances.xsl";
				$modelPrefix = isset($_REQUEST['modelPrefix'])?$_REQUEST['modelPrefix']:'model';
				$powlModel = isset($_REQUEST['modelFromPowl'])?$_REQUEST['modelFromPowl']:'';
				$actualPicturePath = 'img/4.png';
				$nextStep = 'instancesCreated';
				$actualHint = 'Your ontology has been created.';
				$last = true;
				$mapAreas = $area_xml . $area_schema . $area_model . $area_stylesheet . $area_instances;
			}
		}
		else if($docType == 'xsd') {
			if($input == 'upload' || $input == 'enterCode') {
				$input = 'createOWLModel';
				$opPrefix = isset($_REQUEST['opPrefix'])?$_REQUEST['opPrefix']:'has';
				$dtpPrefix = isset($_REQUEST['dtpPrefix'])?$_REQUEST['dtpPrefix']:'dtp';
				$camelCase = isset($_REQUEST['camelCase'])?'true':'false';
				$funcPropSupp = isset($_REQUEST['funcPropSupp'])?'true':'false';
				$actualPicturePath = 'img/owlModelCreated.png';
				$actualHint = 'The OWL model has been created.';
				$last = true;
				$mapAreas = $area_schema . $area_model;
			}
		}
	}
	else {
		$input = 'chooseXML';
		$actualHint = 'You forgot to choose a file!';
	}
}
else {
	$input = $_REQUEST['input'];
}

include('header.inc.php');

switch($input) {

	case 'chooseXML':
		include('chooseInput.inc.php');
		break;
	case 'generateXSD':
		include('generateXSD.inc.php');
		break;
	case 'createOWLModel':
		include('createOWLModel.inc.php');
		break;
	case 'createInstances':
		include('createOWLInstances.inc.php');
		break;
	case 'help':
		include('help.inc.php');
		break;
	case 'about':
		include('about.inc.php');
		break;
	default:
		include('chooseInput.inc.php');

}

include('footer.inc.php');
?>
