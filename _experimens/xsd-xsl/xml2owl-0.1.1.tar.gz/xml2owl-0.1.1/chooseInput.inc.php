<?
/**
 * Include file, which offers different input possibilities.
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: chooseInput.inc.php,v 1.5 2005/09/19 11:22:13 brischniz Exp $
 **/
?>
<div id="chooseInput">
	<input type="radio" name="input" value="chooseXML" onclick="xml2owl.formOptions(this);xml2owl.toggleOptions('chooseXML');document.getElementById('mainImg').src='img/1.png';" checked="checked"/> Example XML document<br/>
	<div id="chooseXML">
		<input type="radio" name="chosenXMLFile" value="<?=$xmlOnServer[0]?>" onclick="document.getElementById('mainImg').src='img/1.png'"/> Citeseer sample file <a href="#" onclick="xml2owl.showCode('xml/oai_citeseer1');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a><br/>
		<input type="radio" name="chosenXMLFile" value="<?=$xmlOnServer[1]?>" onclick="document.getElementById('mainImg').src='img/1.png'"/> MySQL database sample <a href="#" onclick="xml2owl.showCode('xml/example1.xml');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a><br/>
		<input type="radio" name="chosenXMLFile" value="<?=$xmlOnServer[2]?>" onclick="document.getElementById('mainImg').src='img/1.png'"/> MS Excel sample <a href="#" onclick="xml2owl.showCode('xml/exceltest.xml');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a><br/>
		<input type="radio" name="chosenXMLFile" value="<?=$xmlOnServer[3]?>" onclick="document.getElementById('mainImg').src='img/1.png'"/> Firebird sample table <a href="#" onclick="xml2owl.showCode('xml/firebird_job.xml');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a><br/><br/>
	</div>

	<input type="radio" name="input" value="upload" onclick="xml2owl.formOptions(this);xml2owl.toggleOptions('upload');document.getElementById('mainImg').src='img/1.png';document.getElementById('optSchemaExt').style.display='block';document.getElementById('optModelExt').style.display='none';document.mainForm.filetype[0].checked=true;"/> Upload a file<br/>
	<div id="upload">
	<br/><br/>
	<input type="file" name="file" size="50"/><br/>
	<span style="font-size:12px;">(Attention: max. filesize for upload: <b><?=ini_get('upload_max_filesize')?></span></b>)<br/>
	</div>

	<input type="radio" name="input" value="enterCode" onclick="xml2owl.formOptions(this);xml2owl.toggleOptions('enterCode');document.getElementById('mainImg').src='img/1.png';document.getElementById('optSchemaExt').style.display='block';document.getElementById('optModelExt').style.display='none';document.mainForm.filetype[2].checked=true;"/> Enter your own code<br/>
  <div id="enterCode">
    <span id="pasteXML" style="display:block;">
      <textarea id="paste" name="userXML" cols="55" rows="7">&lt;?xml version="1.0"?&gt;
&lt;rootElement&gt;
  &lt;one attrib1="contentOfAttrib1"/&gt;
  &lt;two&gt;
    &lt;three attrib2="contentOfAttrib2"&gt;content&lt;/three&gt;
  &lt;/two&gt;
&lt;/rootElement&gt;
      </textarea>
    </span>
  </div>
</div>

<div id="inputOptions" class="options">

	<div id="optUpload">
		<h3>Options for file upload</h3>
		<span style="margin-left:15px;">
			Filetype:
			<input type="radio" name="filetype" value="xml"  onclick="document.getElementById('optSchemaExt').style.display='block';document.getElementById('optModelExt').style.display='none';document.getElementById('mainImg').src='img/1.png';"/> XML
			<input type="radio" name="filetype" value="xsd" onclick="document.getElementById('optSchemaExt').style.display='none';document.getElementById('optModelExt').style.display='block';document.getElementById('mainImg').src='img/2.png';"/> XSD
		</span>
		<br/>
	</div>

	<div id="optPaste">
		<h3>Options</h3>
		<span style="margin-left:15px;">Filetype:
			<input type="radio" name="filetype" value="xml" onclick="xml2owl.togglePasteType('xml');"/> XML
			<input type="radio" name="filetype" value="xsd" onclick="xml2owl.togglePasteType('xsd');"/> XSD
		</span>
		<br/>
	</div>

	<div id="optSchemaExt">
		<h3>Options for the Schema extraction</h3>
		<span style="margin-left:15px;">
			<input type="checkbox" name="guessCard" value="true"/> Check, if you want the stylesheet to guess the cardinality of the elements<a onMouseOver="return overlib('Stylesheet guesses the cardinality of the elements. The default value is false. That means minOccurs=0 and maxOccurs=unbounded.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a>
		</span>
		<br/>
	</div>

	<div id="optModelExt">
		<h3>Options for the OWL model extraction</h3>
		<input type="checkbox" name="camelCase" value="true"/>
		Check, if you want CamelCase for classes and properties <a onMouseOver="return overlib('This option formats the OWL output with CamelCase. ', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a><br/>
		<input type="checkbox" name="funcPropSupp" value="true"/>
		Detect functional properties <a onMouseOver="return overlib('Stylesheet tries to detect functional properties. Every xsd:attribute and every xsd:element with minOccurs={0|1} and maxOccurs=1 will become a functional property.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a><br/>
		<input type="text" name="opPrefix" value="has"/> Prefix for ObjectProperties<a onMouseOver="return overlib('This sets the prefix for the owl:ObjectProperties. The default value is has.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a><br/>
		<input type="text" name="dtpPrefix" value="dtp"/> Prefix for DatatypeProperties<a onMouseOver="return overlib('This sets the prefix for the owl:DatatypeProperties. The default value is dtp.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a>
		<br/>
	</div>
	<script language="javascript">
		document.getElementById('optSchemaExt').style.display='block';
	</script>
</div>


