<?
/**
 * Informations about the project
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: about.inc.php,v 1.4 2005/09/19 11:22:13 brischniz Exp $
 **/
?>
<div id="about">
<h3>This is a demonstration platform for the XML2OWL stylesheets</h3>
<p>
  It converts a given XML instance files to an OWL ontology. 
  You can also extract an OWL model only out of an XML Schema file. 
  If there is no XML Schema available, one will be generated from the XML instance document.
  OWL instances can be combined with their model.
</p>
<p>
  This is a subproject of my thesis at the university of Leipzig. 
</p>
<p>
  You need a working webserver like Apache with enabled PHP support. 
  For the XSLT processing we need an XSLT processor, which supports the extensions
  from exslt.org. <br/>
  Therefore we have 2 possibilities:
  <ul>
    <li>PHP version &gt;= 5: libxslt support is integrated and we can use predefined classes like 'XSLTProcessor'</li>
    <li>PHP version &lt; 5: we can call an external XSLT processor, which supports the exslt extensions like <b>xsltproc</b></li>
  </ul>
</p>
<p>
  The application has been tested under the following configurations:
  <ul>
    <li>Linux 2.6.8 Suse 9.2, Apache 2.0.50, PHP 4.3.8</li>
    <li>Linux 2.6.10 FC2, Apache 1.3.33, PHP 4.3.11</li>
    <li>Linux 2.6.11 Suse 9.3, Apache 2.0.53, PHP 5.0.3, libxslt 1.1.12</li>
  </ul>
</p>
<p>
  The XML2OWL stylesheets have also been tested in conjunction with the semantic web platform <b><a href="http://powl.sf.net">pOWL</a></b>.
</p>

<br/><br/><br/>
For any questions contact me under <a href="mailto:xml2owl@brischniz.de">xml2owl (at) brischniz.de</a>
<br/><br/><br/>
</div>