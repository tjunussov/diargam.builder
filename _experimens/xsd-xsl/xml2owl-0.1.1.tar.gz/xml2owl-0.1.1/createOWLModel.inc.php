<?
/**
 * Include-file which provides the mapping to an OWL model. It also generates a suitable
 * XSLT stylesheet for the later mapping of the XML instance data.
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: createOWLModel.inc.php,v 1.10 2005/09/21 07:55:53 brischniz Exp $
 **/
 

  $schema = $docType=='xml'?$_XML2OWL['targetPath'].'/schema.xsd':$chosenXMLFile;
  $ontComment = "Automatically created: " . date("D M j G:i:s Y");
  
  if($builtin_libxslt) {
  	$xsl = new XSLTProcessor();
  	$xsl->importStylesheet(DOMDocument::load($_XML2OWL['pathToMainStylesheet']));
  	
    $xsl->setParameter('', 'input', 'xsd');	
    $xsl->setParameter('', 'opPrefix', $opPrefix);
    $xsl->setParameter('', 'dtpPrefix', $dtpPrefix);
    $xsl->setParameter('', 'targetPath', $_XML2OWL['targetPath']);
    $xsl->setParameter('', 'camelCase', $camelCase);
    $xsl->setParameter('', 'toggleFunctionalPropertySupport', $funcPropSupp);
    $xsl->setParameter('', 'pathToXSLTSLlib', $_XML2OWL['pathToXSLTSLlib']);
    $xsl->setParameter('', 'namespace_uri', $_XML2OWL['localURI']);
    $xsl->setParameter('', 'ontologyComment', $ontComment);
      
    $xsl->transformToXML(DOMDocument::load($schema));
  }
  else {
    $param_string = "--stringparam input 'xsd'";
    $param_string .= " --stringparam targetPath '" . $_XML2OWL['targetPath'] . "'";
    $param_string .= " --stringparam opPrefix '" . $opPrefix . "'";
    $param_string .= " --stringparam dtpPrefix '" . $dtpPrefix . "'";
    $param_string .= " --stringparam camelCase '" . $camelCase . "'";
    $param_string .= " --stringparam toggleFunctionalPropertySupport '" . $funcPropSupp . "'";
    $param_string .= " --stringparam pathToXSLTSLlib '" . $_XML2OWL['pathToXSLTSLlib'] . "'";
    $param_string .= " --stringparam namespace_uri '" . $_XML2OWL['localURI'] . "'";
    $param_string .= " --stringparam ontologyComment '" . $ontComment . "'";
    
    $exec_string = $_XML2OWL['pathToXsltproc'] . " " . $param_string . " " . $_XML2OWL['pathToMainStylesheet'] . " " . $schema;
    //echo $exec_string;
    echo "<!-- exec_string: " . $exec_string . "-->\n";
    shell_exec($exec_string);
   
    
  }
?>
<div id="OWLModelcreated">
	<h4>Here is the generated OWL model + stylesheet</h4>
	<ul>
		<li><a href="filedownload.php?file=<?=$_XML2OWL['targetPath']?>/model.owl">model.owl <img src="img/d1.ico" width="13"/></a>
	<a href="#" onclick="xml2owl.showCode('<?=$_XML2OWL['targetPath']?>/model.owl');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a></li>
	<li><a href="filedownload.php?file=<?=$_XML2OWL['targetPath']?>/createInstances.xsl">createInstances.xsl <img src="img/d1.ico" width="13"/></a>
	<a href="#" onclick="xml2owl.showCode('<?=$_XML2OWL['targetPath']?>/createInstances.xsl');"><img src="img/lupe.gif" onMouseOver="return overlib('Click here for looking at the code in a popup window.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();"/></a></li>
	</ul>
</div>

<div id="OWLModelcreatedRightSide" class="options">
	<?if(!$last) {?>
		<div id="optCreateInst">
			<h3>Options for the OWL instances creation</h3>
			<input type="text" name="modelPrefix" value="model"/> Namespace prefix for the model <a onMouseOver="return overlib('This parameter is used for determining the namespace prefix for the OWL model.', CAPTION, 'Help', FGCOLOR, 'FF9933', BGCOLOR, '000000', CAPCOLOR, 'FF9933');" onMouseOut="nd();">[?]</a>
		</div>

		<div id="addModelFromPowl">
			<?if($_XML2OWL['standalone'] == 'no') {?>
			<h3>Select an OWL model for the instances</h3>
			<select name="modelFromPowl">
				<option value="" selected="selected"/>Take the generated OWL model</option>
				<?foreach($_ET['store']->listModels() as $model) {
						echo('<option value="'.$model->modelURI.'"'.($_SESSION['_ETS']['model']==$model->modelURI?' selected':'').'>'.$model->modelURI.'</option>');
				}?>
			</select>
			<?}?>
		</div>
		<script language="javascript">
			document.getElementById('optCreateInst').style.display='block';
			document.getElementById('addModelFromPowl').style.display='block';
		</script>
	<?}
  else {
		if($_XML2OWL['standalone'] == 'no') {?>
		<div id="powlLoad">
			<h3>Load this ontology into pOWL</h3>
			<input id="delFiles" type="checkbox" name="delFiles" value="true" style="margin-left:25px;"/> Delete created files after import
			<a href="#" onclick="xml2owl.forwardToPowlLoad('<?=$tmpID?>', 'model.owl');" style="margin-left:25px;"><img id="btn_loadintopowl" src="img/btn_loadintopowl.png" onmouseover="document.getElementById('btn_loadintopowl').src='img/btn_loadintopowl_mover.png'" onmouseout="document.getElementById('btn_loadintopowl').src='img/btn_loadintopowl.png'"/></a>
		</div>
		<?}else {?>
		<div>
			<a href="index.php?input=del&amp;delID=<?=$tmpID?>">Delete temporary files and return to Startpage <img src="img/delete.gif"/></a>
		</div>
		<?}
	}?>
</div>
		