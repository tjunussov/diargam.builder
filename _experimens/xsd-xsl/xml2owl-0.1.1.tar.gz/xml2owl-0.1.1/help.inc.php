<?
/**
 * Help page
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: help.inc.php,v 1.4 2005/09/19 11:22:13 brischniz Exp $
 **/
?>

<div id="help">
	
	<h3>Here are some informations about the mapping and the implementation.</h3>
		<p>
			The conversion process requires at most three steps (XML instance data only) and at least one step (XML schema only). When processing XML schema only, we only create the model of the ontology with classes and properties.
		</p>
		<p>
			If we have XML instance data only, the first step extracts an XML schema out of the XML instance data so that we could create the model in the second step. Unfortunately such a generated XML Schema is not complete, because XML instance documents do not contain as much information about constraints as a manual created XML Schema. But it serves as a good basis. A configured stylesheet, which converts the XML instance data into the instances part of the ontology, is created simultaneously. It determines whether elements become classes or properties. That is necessary, because the XML instance data can have optional elements or attributes and the created stylesheet will be their common denominator.
		</p>
		<p>
			This framework is designed to be easily extensible, so that the support for the missing XSD components can be included and a better support for document oriented XML can be integrated.
		</p>
		<p>
			At this time, the project consists of 3 stylesheets, which are used for the different transformations:
		</p>
		<ul>
			<li>
				<b>xsd2owl.xsl</b> is the mainstylesheet, which controlles the transformationprocess and call the other stylesheets. It convert given XML schema files to an ontology. Up to now, not all XSD features are supported...I am working on it.
			</li>
			<li>
				<b>xml2xsd.xsl</b> is a helping stylesheet, which creates a XML schema out of a given XML instance document
			</li>
			<li>
				<b>createOWLModel.xsl</b> is a sub-stylesheet, which is called by xsd2owl.xsl. It transform XML instance documents into OWL with classes and instances. There is an option for splitting the result into a model part (classes/properties) and an instance part (therefore look at the documentation).
			</li>
			<li>
				<b>createStylesheet.xsl</b>
			</li>
		</ul>
	
	<p><b>Correspondance of XML-Elements with RDFS/OWL-Elements:</b></p>
	<table id="tab_help_corr" class="tab_help_corr" width="550">
		<tr>
			<th>XSD</th>
			<th>OWL</th>
		</tr>
		<tr>
			<td>xsd:elements, containing other elements or having at least one attribute</td>
			<td>owl:Class, coupled with owl:ObjectProperties</td>
		</tr>
		<tr>
			<td>xsd:elements, with neither sub-elements nor attributes</td>
			<td>owl:DatatypeProperties</td>
		</tr>
		<tr>
			<td>named xsd:complexType</td>
			<td>owl:Class</td>
		</tr>
		<tr>
			<td>named xsd:SimpleType</td>
			<td>owl:DatatypeProperty</td>
		</tr>
		<tr>
			<td>xsd:minOccurs, xsd:maxOccurs</td>
			<td>owl:minCardinality, owl:maxCardinality</td>
		</tr>
		<tr>
			<td>xsd:sequence, xsd:all</td>
			<td>owl:intersectionOf</td>
		</tr>
		<tr>
			<td>xsd:choice</td>
			<td>combination of owl:intersectionOf, owl:unionOf and owl:complementOf</td>
		</tr>
	</table>
	<br/><br/>
  <p>
		This PHP demonstration application consists of 4 main scripts (one for each step):<br/>
		<ul>
			<li><i>chooseInput.inc</i> - select the file or code for processing</li>
			<li><i>generateXSD.inc</i> - extracts an XML Schema out of XML instance data</li>
			<li><i>createOWLModel.inc</i> - transforms an XML Schema to an OWL model and creates a configured stylesheet for the instance processing</li>
			<li><i>createOWLInstances.inc</i> - uses the stylesheet and converts the XML instances to OWL instances</li>
		</ul>
	</p>
	<br/>
	<h3>Some information about the integrating of the stylesheets in your PHP projects</h3>
	<p>
		The usage of the stylesheets within PHP is very easy, but it depends on the version of your PHP. The difference is the integration of the libxslt library in PHP 5.x. In versions lesser than 5 we have to use an external XSLT processor, which supports the extensions from <a href="http://exslt.org">exslt.org</a> like xsltproc.
	</p>
	<p>
		Within PHP5 only the following code is needed to use the stylesheets for extracting
		an OWL ontology out of an XML instance file.
	</p>
	<p>
		<span style="color:blue;">&lt;?php</span><br/><br/>
		<span style="color:orange;">// initialization of the XSLT processor</span><br/>
		<span style="color:blue;">$xsl <span style="color:green;">=</span> new XSLTProcessor();</span><br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>importStylesheet<span style="color:green;">(</span>DOMDocument<span style="color:green;">::</span>load<span style="color:green;">(</span><span style="color:green;">(</span><span style="color:red;">'xsd2owl.xsl'</span><span style="color:green;">));</span></span><br/>
		<br/>
		<span style="color:orange;">// sets the minimum parameter</span><br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>setParameter<span style="color:green;">(</span><span style="color:red;">''</span><span style="color:green;">,</span> <span style="color:red;">'input'</span><span style="color:green;">,</span> <span style="color:red;">'xml'</span><span style="color:green;">);</span>	<br/>
		<br/>
		<span style="color:orange;">// creates an XML Schema file 'schema.xsd'</span><br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>transformToXML<span style="color:green;">(</span>DOMDocument<span style="color:green;">::</span>load<span style="color:green;">(</span><span style="color:red;">'example.xml'</span><span style="color:green;">))</span>;</span><br/>
		<br/>
		<span style="color:orange;">// creates the OWL model</span><br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>setParameter<span style="color:green;">(</span><span style="color:red;">''</span><span style="color:green;">,</span> <span style="color:red;">'input'</span><span style="color:green;">,</span> <span style="color:red;">'xsd'</span><span style="color:green;">);</span></span>	<br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>transformToXML<span style="color:green;">(</span>DOMDocument<span style="color:green;">::</span>load<span style="color:green;">(</span><span style="color:red;">'schema.xsd'</span><span style="color:green;">));</span></span><br/>
		<br/>
		<span style="color:orange;">// importing the created stylesheet for processing the instances</span><br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>importStylesheet<span style="color:green;">(</span>DOMDocument<span style="color:green;">::</span>load<span style="color:green;">(</span><span style="color:red;">'createInstances.xsl'</span><span style="color:green;">));</span></span><br/>
		<br/>
		<span style="color:orange;">// creates the final ontology including the OWL model and the instances</span><br/>
		<span style="color:blue;">$xsl<span style="color:green;">-></span>transformToXML<span style="color:green;">(</span>DOMDocument<span style="color:green;">::</span>load<span style="color:green;">(</span><span style="color:red;">'example.xml'</span><span style="color:green;">));</span></span><br/>
		<br/>
		<span style="color:blue;">?&gt;</span>
	</p>
	<br/>
	For further information look at <a href="http://www.semanticscripting.org/XML2OWL_XSLT">www.semanticscripting.org/XML2OWL_XSLT</a>.
	<br/><br/><br/><br/>
</div>
