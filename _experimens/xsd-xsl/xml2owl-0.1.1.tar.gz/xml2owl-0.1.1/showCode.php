<?
/**
* Show the content of an XML file in a popup window. An external
* XSLT stylesheet for formatting is used.
*
* @package xml2owl
* @author Hannes Bohring
* @copyright Copyright (c) 2005
* @version $Id: showCode.php,v 1.2 2005/09/15 19:03:57 brischniz Exp $
**/
	ini_set('display_errors', 1);
	error_reporting(E_ALL ^ E_WARNING);
?>
<html>
	<head>
		<title>XML2OWL - mapping wizard</title>
		<meta http-equiv="Content-Type" content="text/html;UTF-8"/>
  	<link rel="stylesheet" type="text/css" href="css/xmlverbatim.css"/>
	</head>
<body>

<?
	$xml2html = "xsl/xmlverbatim.xsl";
	$path = $_REQUEST['path'];
	
  if(class_exists('XSLTProcessor')) {
    $xsl = new XSLTProcessor();
    
    $res = DOMDocument::load($path);
  
    $xsl->importStylesheet(DOMDocument::load($xml2html));
    echo $xsl->transformToXML($res);
  }
  else {
    $exec_string = "xsltproc " . $xml2html . " " . $path;
    echo shell_exec($exec_string);
  }
?>

</body>
</html>