<?
/**
 * File download functionality.
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: filedownload.php,v 1.2 2005/09/15 19:03:57 brischniz Exp $
 **/
 
$file = $_REQUEST['file'];

header("Content-type: text/xml");
header("Content-Disposition: attachment; filename=" . basename($file));

readfile($file);

?>