/**
 * Collection of crucial Javascript scripts
 * 
 * @author Hannes Bohring
 * @copyright Copyright (c) 2004
 * @version $Id: functions.js,v 1.3 2005/09/19 11:22:13 brischniz Exp $
 **/


/**
	Javascript class xml2owl
*/
function xml2owl() {
	this.agent = navigator.userAgent.toLowerCase();
	this.isIE = ((this.agent.indexOf("msie") != -1) && (this.agent.indexOf("opera") == -1));
}

/**
	Toggles between the different input variants in chooseInput.inc.php.
*/
xml2owl.formOptions=function(elem) {
	var elements;
	if(elem.options)
		elements=elem.options;
	else if(typeof elem=='string' && document.getElementsByName(elem)) {
		elements=document.getElementsByName(elem);
		if(elements[0] && elements[0].options)
			elements=elements[0].options;
	}
	else
		elements=document.getElementsByName(elem.name);
	var done=false;
	if(elements) for(var i=0;i<elements.length;i++) {
		if(elements[i].value && document.getElementById(elements[i].value)!=null) {
			if(elements[i].checked || elements[i].selected) {
				done=true;
				this.setVisibility(elements[i].value,'block');
			} else
				this.setVisibility(elements[i].value,'none');
		}
		else if(elements[i].value && document.getElementsByName(elements[i].value).length>0) {
			for(section in document.getElementsByName(elements[i].value)) {
				if(elements[i].checked || elements[i].selected) {
					done=true;
					this.setVisibility(section,'block');
				} else
					this.setVisibility(section,'none');
			}
		}
	}
	ele=typeof elem=='string'?elem:elem.name;
	if(done)
		this.setVisibility(ele+'Default','none');
	else
		this.setVisibility(ele+'Default','block');
}


xml2owl.setVisibility=function(id,block) {
	id=(typeof id=='string'?document.getElementById(id):id);
	if(!id) return;
	if(id.style)
		id.style.display=block;
	else
		id.setAttribute('style','display:'+block);
}

/**
	Toggles between the different options in chooseInput.inc.php.
*/
xml2owl.toggleOptions = function (elem) {

	switch (elem) {
		case 'chooseXML':
			document.getElementById('optSchemaExt').style.display='block';
			document.getElementById('optUpload').style.display='none';
			document.getElementById('optPaste').style.display='none';
			break;
		case 'upload':
			document.getElementById('optSchemaExt').style.display='none';
			document.getElementById('optUpload').style.display='block';
			document.getElementById('optPaste').style.display='none';
			break;
		case 'enterCode':
			document.getElementById('optSchemaExt').style.display='none';
			document.getElementById('optUpload').style.display='none';
			document.getElementById('optPaste').style.display='block';
			break;
	}
}

/**
	Shows the beautified XML code of the given XML file in a popup window.
*/
xml2owl.showCode = function (path) {
	window.open("showCode.php?path=" + path, "The source", "width=400,height=600");
}

/**
	Forwards the URL of the generated ontology to the PHP script, which loads the file
	into pOWL. 
*/
xml2owl.forwardToPowlLoad = function (tmpID, filenam) {
	var tmpURL = "powlLoad.php?tmpID=" + tmpID + "&file=" + filenam  + "&delFiles=";

	if(document.getElementById("delFiles").checked) {
		tmpURL += "true";
	}
	else {
		tmpURL += "false";
	}
	//alert(tmpURL);
	window.open(tmpURL,'powlLoad', 'width=10,height=10');
}

/**
	Toggles the content of the textarea field in the chooseInput.inc.php from
	an XML example to an XSD example.
*/
xml2owl.togglePasteType = function (typ) {

	if(typ == "xml") {
		document.getElementById('optSchemaExt').style.display='block';
		document.getElementById('optModelExt').style.display='none';
		document.getElementById('mainImg').src='img/1.png';
		document.getElementById('pasteXML').style.display='block';
		document.getElementById('paste').value = "<?xml version=\"1.0\"?>\n" +
																						"<rootElement>\n" +
																						"  <one attrib1=\"contentOfAttrib1\"/>\n" +
																						"  <two>\n" +
																						"    <three attrib2=\"contentOfAttrib2\">content</three>\n" +
																						"  </two>\n" +
																						"</rootElement>";
	}
	else {
		document.getElementById('optSchemaExt').style.display='none';
		document.getElementById('optModelExt').style.display='block';
		document.getElementById('mainImg').src='img/2.png';
		document.getElementById('pasteXML').style.display='block';
		document.getElementById('paste').value = "<?xml version=\"1.0\"?>\n" +
			"<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\n" +
			"  <xsd:element name=\"rootElement\">\n" +
			"    <xsd:complexType>\n" +
			"      <xsd:sequence>\n" +
			"        <xsd:element ref=\"one\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n" +
			"        <xsd:element ref=\"two\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n" +
			"      </xsd:sequence>\n" +
			"    </xsd:complexType>\n" +
			"  </xsd:element>\n" +
			"  <xsd:element name=\"one\">\n" +
			"    <xsd:complexType>\n" +
			"      <xsd:simpleContent>\n" +
			"        <xsd:extension base=\"xsd:string\">\n" +
			"          <xsd:attribute name=\"attrib1\" type=\"xsd:string\"/>\n" +
			"        </xsd:extension>\n" +
			"      </xsd:simpleContent>\n" +
			"    </xsd:complexType>\n" +
			"  </xsd:element>\n" +
			"  <xsd:element name=\"two\">\n" +
			"    <xsd:complexType>\n" +
			"      <xsd:sequence>\n" +
			"        <xsd:element ref=\"three\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n" +
			"      </xsd:sequence>\n" +
			"    </xsd:complexType>\n" +
			"  </xsd:element>\n" +
			"  <xsd:element name=\"three\">\n" +
			"    <xsd:complexType content=\"mixed\">\n" +
			"      <xsd:simpleContent>\n" +
			"        <xsd:extension base=\"xsd:string\">\n" +
			"          <xsd:attribute name=\"attrib2\" type=\"xsd:string\"/>\n" +
			"        </xsd:extension>\n" +
			"      </xsd:simpleContent>\n" +
			"    </xsd:complexType>\n" +
			"  </xsd:element>\n" +
			"</xsd:schema>";
	}
};
