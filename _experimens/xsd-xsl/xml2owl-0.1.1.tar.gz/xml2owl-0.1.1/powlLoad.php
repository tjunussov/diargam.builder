<?
/**
 * Script loads the created ontology into pOWL - Semantic Web Developement Platform
 * 
 * @package xml2owl
 * @author Hannes Bohring
 * @copyright Copyright (c) 2005
 * @version $Id: powlLoad.php,v 1.4 2005/09/15 19:03:57 brischniz Exp $
 **/

ini_set('display_errors', 1);
error_reporting(E_ALL);

include('config.inc.php');
include('functions.inc.php');
//include('../../include.php');


// ** fuer entfernten pOWL, funzt noch nicht...
// $powl_server = 'localhost';
// $powl_port = '80';
// $powl_url = '/powl/modules/models/model_edit.php';
// $model_uri = $_XML2OWL['localURI'] . '/tmp/' . $_REQUEST['tmpID'] . '/model.owl';
// $powl_params = array("create"=>"import", "model"=>$model_uri);
// 
// echo '<div style="background-color:#CC9090;margin:2px;width:300px;border:1px solid black;"><table style="font-size:12px;">';
// 		echo "<tr><td><b>model_uri:</b></td><td>" . $model_uri . "</td></tr>";
// 	echo '</table></div>';
// 
// 
// echo http_post($powl_server, $powl_port, $powl_url, $powl_params);


// ** fuer lokalen pOWL
$model_uri = $_XML2OWL['localURI'] . '/tmp/' . $_REQUEST['tmpID'] . '/' . $_REQUEST['file'];

//$powl->loadModel("hannestest", $model_uri, true);
$powl->loadModel($model_uri, $model_uri, true);

if($_REQUEST['delFiles'] == 'true') {
	$delPath = $_XML2OWL['targetPath'] . '/' . $_REQUEST['tmpID'];
	rmdirr($delPath);
}


?>

<script language="javascript">
	opener.location.href="http://localhost/powl";
	close();
</script>